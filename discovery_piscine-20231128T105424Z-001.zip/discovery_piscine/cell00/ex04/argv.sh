if [ "$#" -eq 0 ]; then
    echo "No arguments supplied"
else
    count=0
    for arg in "$@"; do
        if [ "$count" -lt 3 ]; then
            echo "$arg"
            ((count++))
        fi
    done
fi
# this script checks whether any arguments are supplied. 
#If no arguments are provided, 
# it prints the message "No arguments supplied." 
#If there are arguments, it uses a loop to iterate over each argument 
# and prints them on separate lines.
# The if, else, for, do, and fi are control flow and 
# loop constructs in Bash scripting. 
#The count variable is used to limit the number 
# of displayed arguments to a maximum of three.
