ls | wc -l
