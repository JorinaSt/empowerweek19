ls | wc -l 
