// Get the reference to the balloon div using its id
const balloon = document.getElementById("balloon");

// Initialize the starting size of the balloon
let size = 200;

// Initialize the color index to determine the current color of the balloon
let colorIndex = 0;

// Function to handle the growth of the balloon on click
function growBalloon() {
    // Increase the size of the balloon by 10 pixels
    size += 10; // 210 -> 220
    
    if (colorIndex > 1)
        colorIndex = 0;
    else
        colorIndex++; // 2

    // If the size exceeds 420 pixels, reset the size and color to their initial values
    if (size > 420) {
        size = 200;
        colorIndex = 0;
    }

    // Update the balloon's size and color
    updateBalloon();
}

// // // Function to handle the shrinking of the balloon on mouseenter
function shrinkBalloon() {
    // Shrink the size of the balloon by 5 pixels, but not below the minimum size of 200 pixels
    size = Math.max(size - 5, 200);

    // Reverse the color order when shrinking
    colorIndex = (colorIndex - 1 + 3) % 3;

    // Update the balloon's size and color
    updateBalloon();
}

// // Function to handle the reset of the balloon on mouseleave
// function resetBalloon() {
//     // Shrink the size of the balloon by 5 pixels, but not below the minimum size of 200 pixels
//     size = Math.max(size - 5, 200);

//     // Reverse the color order when resetting
//     colorIndex = (colorIndex - 1 + 3) % 3;

//     // Update the balloon's size and color
//     updateBalloon();
// }

// Function to update the balloon's size and color
function updateBalloon() {
    // Array of colors in the order: red, green, blue
    const colors = ["red", "green", "blue"];

    // Set the width and height of the balloon to the updated size
    balloon.style.width = size + "px";
    balloon.style.height = size + "px";

    // Set the background color of the balloon to the current color based on the color index
    balloon.style.backgroundColor = colors[colorIndex];
}

// balloon.addEventListener("click",  growBalloon())
// balloon.addEventListener("mouseout",  resetBalloon())
