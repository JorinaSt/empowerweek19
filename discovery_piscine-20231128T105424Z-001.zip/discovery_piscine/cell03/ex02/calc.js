function calculate() {
    // Get the values from the input fields and the operator
    const leftOperand = parseInt(document.getElementById("leftInput").value, 10);
    const rightOperand = parseInt(document.getElementById("rightInput").value, 10);
    const operator = document.getElementById("operator").value;

    // Check if both operands are positive integers
    if (!Number.isInteger(leftOperand) || !Number.isInteger(rightOperand) || leftOperand < 0 || rightOperand < 0) {
        alert("Error :(");
        return;
    }

    // Perform the calculation based on the selected operator
    let result; // declaration of variable result
    switch (operator) {
        case "+":
            result = leftOperand + rightOperand;
            break;
        case "-":
            result = leftOperand - rightOperand;
            break;
        case "*":
            result = leftOperand * rightOperand;
            break;
        case "/":
            // Check for division by zero
            if (rightOperand === 0) {
                alert("It’s over 9000!");
                return;
            }
            result = leftOperand / rightOperand;
            break;
        case "%":
            // Check for modulo by zero
            if (rightOperand === 0) {
                alert("It’s over 9000!");
                return;
            }
            result = leftOperand % rightOperand;
            break;
        default:
            alert("Invalid operator");
            return;
    }

    // Display the result in an alert message
    alert("Result: " + result);

    // Log the result to the console
    console.log("Result:", result);
}

// Display a pop-up every 30 seconds
setInterval(function () {alert("Please, use me...");}, 30000);
